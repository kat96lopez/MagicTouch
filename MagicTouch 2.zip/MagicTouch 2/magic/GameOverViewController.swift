//
//  GameOverViewController.swift
//  magic
//
//  Created by Kat Lopez on 4/20/18.
//  Copyright © 2018 Harim yu. All rights reserved.
//

import UIKit

class GameOverViewController: UIViewController {
    
    
    var Score = 0
    var Highschore = 0
    

    @IBOutlet weak var overScore: UILabel!
    
    @IBOutlet weak var overHighScore: UILabel!
    
    
    @IBOutlet weak var overHighScores: UILabel!
    
    
    @IBOutlet weak var overScores: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func action() {
        if (Score < 100) {
            Score += 1
            _ = Score < 1 ? String(format: "%1", Score) : String(format: "%.f", round(Double(Score)))
            print("HighScore:\(overScore)")
        } else if (Score >= 100) {
            Score += 100
            let someScore = Score < 1 ? String(format: "%1", Score) : String(format: "%.0f", round(Double(Score)))
            print("HighScore:\(someScore)")
        }
    }
    
}
