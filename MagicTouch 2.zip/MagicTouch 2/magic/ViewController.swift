//
//  ViewController.swift
//  magic
//
//  Created by Harim yu on 4/12/18.
//  Copyright © 2018 Harim yu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var Grey1: UIButton!
    
    @IBOutlet weak var Grey2: UIButton!
    
    @IBOutlet weak var Grey3: UIButton!
    
    @IBOutlet weak var Grey4: UIButton!
    
    @IBOutlet weak var Grey5: UIButton!
    @IBOutlet weak var Grey6: UIButton!
    
    @IBOutlet weak var Grey7: UIButton!
    @IBOutlet weak var Grey8: UIButton!
    
    @IBOutlet weak var Grey9: UIButton!
    
    @IBOutlet weak var Grey10: UIButton!
    
    @IBOutlet weak var Grey11: UIButton!
    
    @IBOutlet weak var Grey12: UIButton!
    
    @IBOutlet weak var Grey13: UIButton!
    @IBOutlet weak var Grey14: UIButton!
    @IBOutlet weak var Grey15: UIButton!
    
    @IBOutlet weak var Grey16: UIButton!
    
    @IBOutlet weak var Grey17: UIButton!
    
    @IBOutlet weak var Grey18: UIButton!
    
    @IBOutlet weak var Grey19: UIButton!
    
    @IBOutlet weak var Grey20: UIButton!
    
    @IBOutlet weak var Grey21: UIButton!
    
    @IBOutlet weak var purple1: UIButton!
    
    @IBOutlet weak var purple2: UIButton!
    
    @IBOutlet weak var purple3: UIButton!
    
    @IBOutlet weak var purple4: UIButton!
    
    @IBOutlet weak var purple5: UIButton!
    
    @IBOutlet weak var purple6: UIButton!
    
    @IBOutlet weak var purple7: UIButton!
    
    
    
    @IBAction func firstDown(_ sender: Any) {
        Grey1.center.y = Grey1.center.y+93
        Grey2.center.y = Grey2.center.y+93
        Grey3.center.y = Grey3.center.y+93
        Grey4.center.y = Grey4.center.y+93
        Grey5.center.y = Grey5.center.y+93
        Grey6.center.y = Grey6.center.y+93
        Grey7.center.y = Grey7.center.y+93
        Grey8.center.y = Grey8.center.y+93
        Grey9.center.y = Grey9.center.y+93
        Grey10.center.y = Grey10.center.y+93
        Grey11.center.y = Grey11.center.y+93
        Grey12.center.y = Grey12.center.y+93
        Grey13.center.y = Grey13.center.y+93
        Grey14.center.y = Grey14.center.y+93
        Grey15.center.y = Grey15.center.y+93
        Grey16.center.y = Grey16.center.y+93
        Grey17.center.y = Grey17.center.y+93
        Grey18.center.y = Grey18.center.y+93
        Grey19.center.y = Grey19.center.y+93
        Grey20.center.y = Grey20.center.y+93
        Grey21.center.y = Grey21.center.y+93
        
        purple1.center.y = purple1.center.y+93
        purple2.center.y = purple2.center.y+93
        purple3.center.y = purple3.center.y+93
        purple4.center.y = purple4.center.y+93
        purple5.center.y = purple5.center.y+93
        purple6.center.y = purple6.center.y+93
        purple7.center.y = purple7.center.y+93
        
        if (purple1.center.y >= 700){
            purple1.center.y = -46.5
            Grey1.center.y = -46.5
            Grey2.center.y = -46.5
            Grey3.center.y = -46.5
            randomPlacement1()
            
        }
        if (purple2.center.y >= 700){
            purple2.center.y = -46.5
            
            Grey4.center.y = -46.5
            Grey5.center.y = -46.5
            Grey6.center.y = -46.5
            randomPlacement2()
            
        }
        if (purple3.center.y >= 700){
            purple3.center.y = -46.5
            
            Grey7.center.y = -46.5
            Grey8.center.y = -46.5
            Grey9.center.y = -46.5
            randomPlacement3()
            
        }
        if (purple4.center.y >= 700){
            purple4.center.y = -46.5
            
            Grey10.center.y = -46.5
            Grey11.center.y = -46.5
            Grey12.center.y = -46.5
            randomPlacement4()
            
        }
        if (purple5.center.y >= 700){
            purple5.center.y = -46.5
            
            Grey13.center.y = -46.5
            Grey14.center.y = -46.5
            Grey15.center.y = -46.5
            randomPlacement5()
        }
        if (purple6.center.y >= 700){
            purple6.center.y = -46.5
            
            Grey16.center.y = -46.5
            Grey17.center.y = -46.5
            Grey18.center.y = -46.5
            randomPlacement6()
            
        }
        if (purple7.center.y >= 700){
            purple7.center.y = -46.5
            
            Grey19.center.y = -46.5
            Grey20.center.y = -46.5
            Grey21.center.y = -46.5
            randomPlacement7()
        }
        
    }
    @IBAction func secondDown(_ sender: Any) {
        Grey1.center.y = Grey1.center.y+93
        Grey2.center.y = Grey2.center.y+93
        Grey3.center.y = Grey3.center.y+93
        Grey4.center.y = Grey4.center.y+93
        Grey5.center.y = Grey5.center.y+93
        Grey6.center.y = Grey6.center.y+93
        Grey7.center.y = Grey7.center.y+93
        Grey8.center.y = Grey8.center.y+93
        Grey9.center.y = Grey9.center.y+93
        Grey10.center.y = Grey10.center.y+93
        Grey11.center.y = Grey11.center.y+93
        Grey12.center.y = Grey12.center.y+93
        Grey13.center.y = Grey13.center.y+93
        Grey14.center.y = Grey14.center.y+93
        Grey15.center.y = Grey15.center.y+93
        Grey16.center.y = Grey16.center.y+93
        Grey17.center.y = Grey17.center.y+93
        Grey18.center.y = Grey18.center.y+93
        Grey19.center.y = Grey19.center.y+93
        Grey20.center.y = Grey20.center.y+93
        Grey21.center.y = Grey21.center.y+93
        
        purple1.center.y = purple1.center.y+93
        purple2.center.y = purple2.center.y+93
        purple3.center.y = purple3.center.y+93
        purple4.center.y = purple4.center.y+93
        purple5.center.y = purple5.center.y+93
        purple6.center.y = purple6.center.y+93
        purple7.center.y = purple7.center.y+93
        
        if (purple1.center.y >= 700){
            purple1.center.y = -46.5
            Grey1.center.y = -46.5
            Grey2.center.y = -46.5
            Grey3.center.y = -46.5
            randomPlacement1()
            
        }
        if (purple2.center.y >= 700){
            purple2.center.y = -46.5
            
            Grey4.center.y = -46.5
            Grey5.center.y = -46.5
            Grey6.center.y = -46.5
            randomPlacement2()
            
        }
        if (purple3.center.y >= 700){
            purple3.center.y = -46.5
            
            Grey7.center.y = -46.5
            Grey8.center.y = -46.5
            Grey9.center.y = -46.5
            randomPlacement3()
            
        }
        if (purple4.center.y >= 700){
            purple4.center.y = -46.5
            
            Grey10.center.y = -46.5
            Grey11.center.y = -46.5
            Grey12.center.y = -46.5
            randomPlacement4()
            
        }
        if (purple5.center.y >= 700){
            purple5.center.y = -46.5
            
            Grey13.center.y = -46.5
            Grey14.center.y = -46.5
            Grey15.center.y = -46.5
            randomPlacement5()
        }
        if (purple6.center.y >= 700){
            purple6.center.y = -46.5
            
            Grey16.center.y = -46.5
            Grey17.center.y = -46.5
            Grey18.center.y = -46.5
            randomPlacement6()
            
        }
        if (purple7.center.y >= 700){
            purple7.center.y = -46.5
            
            Grey19.center.y = -46.5
            Grey20.center.y = -46.5
            Grey21.center.y = -46.5
            randomPlacement7()
        }
    }
    
    @IBAction func thirdDown(_ sender: Any) {
        Grey1.center.y = Grey1.center.y+93
        Grey2.center.y = Grey2.center.y+93
        Grey3.center.y = Grey3.center.y+93
        Grey4.center.y = Grey4.center.y+93
        Grey5.center.y = Grey5.center.y+93
        Grey6.center.y = Grey6.center.y+93
        Grey7.center.y = Grey7.center.y+93
        Grey8.center.y = Grey8.center.y+93
        Grey9.center.y = Grey9.center.y+93
        Grey10.center.y = Grey10.center.y+93
        Grey11.center.y = Grey11.center.y+93
        Grey12.center.y = Grey12.center.y+93
        Grey13.center.y = Grey13.center.y+93
        Grey14.center.y = Grey14.center.y+93
        Grey15.center.y = Grey15.center.y+93
        Grey16.center.y = Grey16.center.y+93
        Grey17.center.y = Grey17.center.y+93
        Grey18.center.y = Grey18.center.y+93
        Grey19.center.y = Grey19.center.y+93
        Grey20.center.y = Grey20.center.y+93
        Grey21.center.y = Grey21.center.y+93
        
        purple1.center.y = purple1.center.y+93
        purple2.center.y = purple2.center.y+93
        purple3.center.y = purple3.center.y+93
        purple4.center.y = purple4.center.y+93
        purple5.center.y = purple5.center.y+93
        purple6.center.y = purple6.center.y+93
        purple7.center.y = purple7.center.y+93
        
        if (purple1.center.y >= 700){
            purple1.center.y = -46.5
            Grey1.center.y = -46.5
            Grey2.center.y = -46.5
            Grey3.center.y = -46.5
            randomPlacement1()
            
        }
        if (purple2.center.y >= 700){
            purple2.center.y = -46.5
            
            Grey4.center.y = -46.5
            Grey5.center.y = -46.5
            Grey6.center.y = -46.5
            randomPlacement2()
            
        }
        if (purple3.center.y >= 700){
            purple3.center.y = -46.5
            
            Grey7.center.y = -46.5
            Grey8.center.y = -46.5
            Grey9.center.y = -46.5
            randomPlacement3()
            
        }
        if (purple4.center.y >= 700){
            purple4.center.y = -46.5
            
            Grey10.center.y = -46.5
            Grey11.center.y = -46.5
            Grey12.center.y = -46.5
            randomPlacement4()
            
        }
        if (purple5.center.y >= 700){
            purple5.center.y = -46.5
            
            Grey13.center.y = -46.5
            Grey14.center.y = -46.5
            Grey15.center.y = -46.5
            randomPlacement5()
        }
        if (purple6.center.y >= 700){
            purple6.center.y = -46.5
            
            Grey16.center.y = -46.5
            Grey17.center.y = -46.5
            Grey18.center.y = -46.5
            randomPlacement6()
            
        }
        if (purple7.center.y >= 700){
            purple7.center.y = -46.5
            
            Grey19.center.y = -46.5
            Grey20.center.y = -46.5
            Grey21.center.y = -46.5
            randomPlacement7()
        }
    }
    @IBAction func fourthDown(_ sender: Any) {
        Grey1.center.y = Grey1.center.y+93
        Grey2.center.y = Grey2.center.y+93
        Grey3.center.y = Grey3.center.y+93
        Grey4.center.y = Grey4.center.y+93
        Grey5.center.y = Grey5.center.y+93
        Grey6.center.y = Grey6.center.y+93
        Grey7.center.y = Grey7.center.y+93
        Grey8.center.y = Grey8.center.y+93
        Grey9.center.y = Grey9.center.y+93
        Grey10.center.y = Grey10.center.y+93
        Grey11.center.y = Grey11.center.y+93
        Grey12.center.y = Grey12.center.y+93
        Grey13.center.y = Grey13.center.y+93
        Grey14.center.y = Grey14.center.y+93
        Grey15.center.y = Grey15.center.y+93
        Grey16.center.y = Grey16.center.y+93
        Grey17.center.y = Grey17.center.y+93
        Grey18.center.y = Grey18.center.y+93
        Grey19.center.y = Grey19.center.y+93
        Grey20.center.y = Grey20.center.y+93
        Grey21.center.y = Grey21.center.y+93
        
        purple1.center.y = purple1.center.y+93
        purple2.center.y = purple2.center.y+93
        purple3.center.y = purple3.center.y+93
        purple4.center.y = purple4.center.y+93
        purple5.center.y = purple5.center.y+93
        purple6.center.y = purple6.center.y+93
        purple7.center.y = purple7.center.y+93
        
        if (purple1.center.y >= 700){
            purple1.center.y = -46.5
            Grey1.center.y = -46.5
            Grey2.center.y = -46.5
            Grey3.center.y = -46.5
            randomPlacement1()
            
        }
        if (purple2.center.y >= 700){
            purple2.center.y = -46.5
            
            Grey4.center.y = -46.5
            Grey5.center.y = -46.5
            Grey6.center.y = -46.5
            randomPlacement2()
            
        }
        if (purple3.center.y >= 700){
            purple3.center.y = -46.5
            
            Grey7.center.y = -46.5
            Grey8.center.y = -46.5
            Grey9.center.y = -46.5
            randomPlacement3()
            
        }
        if (purple4.center.y >= 700){
            purple4.center.y = -46.5
            
            Grey10.center.y = -46.5
            Grey11.center.y = -46.5
            Grey12.center.y = -46.5
            randomPlacement4()
            
        }
        if (purple5.center.y >= 700){
            purple5.center.y = -46.5
            
            Grey13.center.y = -46.5
            Grey14.center.y = -46.5
            Grey15.center.y = -46.5
            randomPlacement5()
        }
        if (purple6.center.y >= 700){
            purple6.center.y = -46.5
            
            Grey16.center.y = -46.5
            Grey17.center.y = -46.5
            Grey18.center.y = -46.5
            randomPlacement6()
            
        }
        if (purple7.center.y >= 700){
            purple7.center.y = -46.5
            
            Grey19.center.y = -46.5
            Grey20.center.y = -46.5
            Grey21.center.y = -46.5
            randomPlacement7()
        }    }
    @IBAction func fifthDown(_ sender: Any) {
        Grey1.center.y = Grey1.center.y+93
        Grey2.center.y = Grey2.center.y+93
        Grey3.center.y = Grey3.center.y+93
        Grey4.center.y = Grey4.center.y+93
        Grey5.center.y = Grey5.center.y+93
        Grey6.center.y = Grey6.center.y+93
        Grey7.center.y = Grey7.center.y+93
        Grey8.center.y = Grey8.center.y+93
        Grey9.center.y = Grey9.center.y+93
        Grey10.center.y = Grey10.center.y+93
        Grey11.center.y = Grey11.center.y+93
        Grey12.center.y = Grey12.center.y+93
        Grey13.center.y = Grey13.center.y+93
        Grey14.center.y = Grey14.center.y+93
        Grey15.center.y = Grey15.center.y+93
        Grey16.center.y = Grey16.center.y+93
        Grey17.center.y = Grey17.center.y+93
        Grey18.center.y = Grey18.center.y+93
        Grey19.center.y = Grey19.center.y+93
        Grey20.center.y = Grey20.center.y+93
        Grey21.center.y = Grey21.center.y+93
        
        purple1.center.y = purple1.center.y+93
        purple2.center.y = purple2.center.y+93
        purple3.center.y = purple3.center.y+93
        purple4.center.y = purple4.center.y+93
        purple5.center.y = purple5.center.y+93
        purple6.center.y = purple6.center.y+93
        purple7.center.y = purple7.center.y+93
        
        if (purple1.center.y >= 700){
            purple1.center.y = -46.5
            Grey1.center.y = -46.5
            Grey2.center.y = -46.5
            Grey3.center.y = -46.5
            randomPlacement1()
            
        }
        if (purple2.center.y >= 700){
            purple2.center.y = -46.5
            
            Grey4.center.y = -46.5
            Grey5.center.y = -46.5
            Grey6.center.y = -46.5
            randomPlacement2()
            
        }
        if (purple3.center.y >= 700){
            purple3.center.y = -46.5
            
            Grey7.center.y = -46.5
            Grey8.center.y = -46.5
            Grey9.center.y = -46.5
            randomPlacement3()
            
        }
        if (purple4.center.y >= 700){
            purple4.center.y = -46.5
            
            Grey10.center.y = -46.5
            Grey11.center.y = -46.5
            Grey12.center.y = -46.5
            randomPlacement4()
            
        }
        if (purple5.center.y >= 700){
            purple5.center.y = -46.5
            
            Grey13.center.y = -46.5
            Grey14.center.y = -46.5
            Grey15.center.y = -46.5
            randomPlacement5()
        }
        if (purple6.center.y >= 700){
            purple6.center.y = -46.5
            
            Grey16.center.y = -46.5
            Grey17.center.y = -46.5
            Grey18.center.y = -46.5
            randomPlacement6()
            
        }
        if (purple7.center.y >= 700){
            purple7.center.y = -46.5
            
            Grey19.center.y = -46.5
            Grey20.center.y = -46.5
            Grey21.center.y = -46.5
            randomPlacement7()
        }
    }
    @IBAction func sixthDown(_ sender: Any) {
        Grey1.center.y = Grey1.center.y+93
        Grey2.center.y = Grey2.center.y+93
        Grey3.center.y = Grey3.center.y+93
        Grey4.center.y = Grey4.center.y+93
        Grey5.center.y = Grey5.center.y+93
        Grey6.center.y = Grey6.center.y+93
        Grey7.center.y = Grey7.center.y+93
        Grey8.center.y = Grey8.center.y+93
        Grey9.center.y = Grey9.center.y+93
        Grey10.center.y = Grey10.center.y+93
        Grey11.center.y = Grey11.center.y+93
        Grey12.center.y = Grey12.center.y+93
        Grey13.center.y = Grey13.center.y+93
        Grey14.center.y = Grey14.center.y+93
        Grey15.center.y = Grey15.center.y+93
        Grey16.center.y = Grey16.center.y+93
        Grey17.center.y = Grey17.center.y+93
        Grey18.center.y = Grey18.center.y+93
        Grey19.center.y = Grey19.center.y+93
        Grey20.center.y = Grey20.center.y+93
        Grey21.center.y = Grey21.center.y+93
        
        purple1.center.y = purple1.center.y+93
        purple2.center.y = purple2.center.y+93
        purple3.center.y = purple3.center.y+93
        purple4.center.y = purple4.center.y+93
        purple5.center.y = purple5.center.y+93
        purple6.center.y = purple6.center.y+93
        purple7.center.y = purple7.center.y+93
        
        if (purple1.center.y >= 700){
            purple1.center.y = -46.5
            Grey1.center.y = -46.5
            Grey2.center.y = -46.5
            Grey3.center.y = -46.5
            
        }
        if (purple2.center.y >= 700){
            purple2.center.y = -46.5
            
            Grey4.center.y = -46.5
            Grey5.center.y = -46.5
            Grey6.center.y = -46.5
            
        }
        if (purple3.center.y >= 700){
            purple3.center.y = -46.5
            
            Grey7.center.y = -46.5
            Grey8.center.y = -46.5
            Grey9.center.y = -46.5
            
        }
        if (purple4.center.y >= 700){
            purple4.center.y = -46.5
            
            Grey10.center.y = -46.5
            Grey11.center.y = -46.5
            Grey12.center.y = -46.5
            
        }
        if (purple5.center.y >= 700){
            purple5.center.y = -46.5
            
            Grey13.center.y = -46.5
            Grey14.center.y = -46.5
            Grey15.center.y = -46.5
            
        }
        if (purple6.center.y >= 700){
            purple6.center.y = -46.5
            
            Grey16.center.y = -46.5
            Grey17.center.y = -46.5
            Grey18.center.y = -46.5
            
        }
        if (purple7.center.y >= 700){
            purple7.center.y = -46.5
            
            Grey19.center.y = -46.5
            Grey20.center.y = -46.5
            Grey21.center.y = -46.5
        }
    }
    @IBAction func seventhDown(_ sender: Any) {
        Grey1.center.y = Grey1.center.y+93
        Grey2.center.y = Grey2.center.y+93
        Grey3.center.y = Grey3.center.y+93
        Grey4.center.y = Grey4.center.y+93
        Grey5.center.y = Grey5.center.y+93
        Grey6.center.y = Grey6.center.y+93
        Grey7.center.y = Grey7.center.y+93
        Grey8.center.y = Grey8.center.y+93
        Grey9.center.y = Grey9.center.y+93
        Grey10.center.y = Grey10.center.y+93
        Grey11.center.y = Grey11.center.y+93
        Grey12.center.y = Grey12.center.y+93
        Grey13.center.y = Grey13.center.y+93
        Grey14.center.y = Grey14.center.y+93
        Grey15.center.y = Grey15.center.y+93
        Grey16.center.y = Grey16.center.y+93
        Grey17.center.y = Grey17.center.y+93
        Grey18.center.y = Grey18.center.y+93
        Grey19.center.y = Grey19.center.y+93
        Grey20.center.y = Grey20.center.y+93
        Grey21.center.y = Grey21.center.y+93
        
        purple1.center.y = purple1.center.y+93
        purple2.center.y = purple2.center.y+93
        purple3.center.y = purple3.center.y+93
        purple4.center.y = purple4.center.y+93
        purple5.center.y = purple5.center.y+93
        purple6.center.y = purple6.center.y+93
        purple7.center.y = purple7.center.y+93
        
        if (purple1.center.y >= 700){
            purple1.center.y = -46.5
            Grey1.center.y = -46.5
            Grey2.center.y = -46.5
            Grey3.center.y = -46.5
            
        }
        if (purple2.center.y >= 700){
            purple2.center.y = -46.5
            
            Grey4.center.y = -46.5
            Grey5.center.y = -46.5
            Grey6.center.y = -46.5
            
        }
        if (purple3.center.y >= 700){
            purple3.center.y = -46.5
            
            Grey7.center.y = -46.5
            Grey8.center.y = -46.5
            Grey9.center.y = -46.5
            
        }
        if (purple4.center.y >= 700){
            purple4.center.y = -46.5
            
            Grey10.center.y = -46.5
            Grey11.center.y = -46.5
            Grey12.center.y = -46.5
            
        }
        if (purple5.center.y >= 700){
            purple5.center.y = -46.5
            
            Grey13.center.y = -46.5
            Grey14.center.y = -46.5
            Grey15.center.y = -46.5
            
        }
        if (purple6.center.y >= 700){
            purple6.center.y = -46.5
            
            Grey16.center.y = -46.5
            Grey17.center.y = -46.5
            Grey18.center.y = -46.5
            
        }
        if (purple7.center.y >= 700){
            purple7.center.y = -46.5
            
            Grey19.center.y = -46.5
            Grey20.center.y = -46.5
            Grey21.center.y = -46.5
        }
    
    
        
    }

    func randomPlacement1(){
        let RandomNumber = arc4random() % 4
        switch(RandomNumber){
        case 0:
            purple1.center.x = 45.5
            Grey1.center.x =  140
            Grey2.center.x = 250
            Grey3.center.x = 360
            break
        case 1:
            purple1.center.x = 150
            Grey1.center.x =  45.5
            Grey2.center.x = 250
            Grey3.center.x = 360
            break
        case 2:
            purple1.center.x = 250
            Grey1.center.x =  150
            Grey2.center.x = 45.5
            Grey3.center.x = 360
            break
        case 3:
            purple1.center.x = 360
            Grey1.center.x =  150
            Grey2.center.x = 250
            Grey3.center.x = 45.5
            break
        default:
            break
            
        }
    }
    
    func randomPlacement2(){
        let RandomNumber = arc4random() % 4
        switch(RandomNumber){
        case 0:
            purple2.center.x = 45.5
            Grey4.center.x =  150
            Grey5.center.x = 250
            Grey6.center.x = 360
            break
        case 1:
            purple2.center.x = 150
            Grey4.center.x =  45.5
            Grey5.center.x = 250
            Grey6.center.x = 360
            break
        case 2:
            purple2.center.x = 250
            Grey4.center.x =  150
            Grey5.center.x = 45.5
            Grey6.center.x = 360
            break
        case 3:
            purple2.center.x = 360
            Grey4.center.x =  150
            Grey5.center.x = 250
            Grey6.center.x = 45.5
            break
        default:
            break
            
        }
        
    }
    func randomPlacement3(){
        let RandomNumber = arc4random() % 4
        switch(RandomNumber){
        case 0:
            purple3.center.x = 45.5
            Grey7.center.x =  150
            Grey8.center.x = 250
            Grey9.center.x = 360
            break
        case 1:
            purple3.center.x = 150
            Grey7.center.x =  45.5
            Grey8.center.x = 250
            Grey9.center.x = 360
            break
        case 2:
            purple3.center.x = 250
            Grey7.center.x =  150
            Grey8.center.x = 45.5
            Grey9.center.x = 360
            break
        case 3:
            purple3.center.x = 360
            Grey7.center.x =  150
            Grey8.center.x = 250
            Grey9.center.x = 45.5
            break
        default:
            break
            
        }
    }
    func randomPlacement4(){
        let RandomNumber = arc4random() % 4
        switch(RandomNumber){
        case 0:
            purple4.center.x = 45.5
            Grey10.center.x =  150
            Grey11.center.x = 250
            Grey12.center.x = 360
            break
        case 1:
            purple4.center.x = 150
            Grey10.center.x =  45.5
            Grey11.center.x = 250
            Grey12.center.x = 360
            break
        case 2:
            purple4.center.x = 250
            Grey10.center.x =  150
            Grey11.center.x = 45.5
            Grey12.center.x = 360
            break
        case 3:
            purple4.center.x = 360
            Grey10.center.x =  150
            Grey11.center.x = 250
            Grey12.center.x = 45.5
            break
        default:
            break
            
        }
        
    }
    func randomPlacement5(){
        let RandomNumber = arc4random() % 4
        switch(RandomNumber){
        case 0:
            purple5.center.x = 45.5
            Grey13.center.x =  150
            Grey14.center.x = 250
            Grey15.center.x = 360
            break
        case 1:
            purple5.center.x = 150
            Grey13.center.x =  45.5
            Grey14.center.x = 250
            Grey15.center.x = 360
            break
        case 2:
            purple5.center.x = 250
            Grey13.center.x =  150
            Grey14.center.x = 45.5
            Grey15.center.x = 360
            break
        case 3:
            purple5.center.x = 360
            Grey13.center.x =  150
            Grey14.center.x = 250
            Grey15.center.x = 45.5
            break
        default:
            break
            
        }
    }
    func randomPlacement6(){
        let RandomNumber = arc4random() % 4
        switch(RandomNumber){
        case 0:
            purple6.center.x = 45.5
            Grey16.center.x =  150
            Grey17.center.x = 250
            Grey18.center.x = 360
            break
        case 1:
            purple6.center.x = 150
            Grey16.center.x =  45.5
            Grey17.center.x = 250
            Grey18.center.x = 360
            break
        case 2:
            purple6.center.x = 250
            Grey16.center.x =  150
            Grey17.center.x = 43.5
            Grey18.center.x = 360
            break
        case 3:
            purple6.center.x = 360
            Grey16.center.x =  150
            Grey17.center.x = 250
            Grey18.center.x = 45.5
            break
        default:
            break
            
        }
        
    }
    func randomPlacement7(){
        let RandomNumber = arc4random() % 4
        switch(RandomNumber){
        case 0:
            purple7.center.x = 45.5
            Grey19.center.x =  150
            Grey20.center.x = 250
            Grey21.center.x = 360
            break
        case 1:
            purple7.center.x = 150
            Grey19.center.x =  45.5
            Grey20.center.x = 250
            Grey21.center.x = 360
            break
        case 2:
            purple7.center.x = 250
            Grey19.center.x =  150
            Grey20.center.x = 45.5
            Grey21.center.x = 360
            break
        case 3:
            purple7.center.x = 360
            Grey19.center.x =  150
            Grey20.center.x = 250
            Grey21.center.x = 45.5
            break
        default:
            break
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

